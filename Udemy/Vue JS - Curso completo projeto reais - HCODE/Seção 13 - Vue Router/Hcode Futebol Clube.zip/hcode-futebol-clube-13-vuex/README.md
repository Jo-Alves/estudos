# curso-vuejs-hcode-futebol-clube
Este repositório contém o projeto da Hcode Futebol Clube, desenvolvido no treinamento Vue.js - Curso Completo

Execute npm install e npm run serve para iniciar o servidor